﻿using PayAndParkBLL;
using PayAndParkEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PayAndParkWebApp
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedIndex == 1)
            {
                lblAmount.Text = "50";
            }
            if (DropDownList1.SelectedIndex == 2)
            {
                lblAmount.Text = "75";
            }
            else
            {
                lblAmount.Text = "125";
            }
            
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                VehicleBLL bll = new VehicleBLL();
                Vehicle vehicle = new Vehicle()
                {
                    OwnerName = txtOwner.Text,
                    ContactNo = txtContactNo.Text,
                    Date = DateTime.Now,
                    RegistrationNo = txtRegistrationNo.Text,
                    TypeofVehicle = DropDownList1.SelectedValue,
                    Amount = double.Parse(lblAmount.Text)

                };
                bll.Add(vehicle);
                lblsuccess.Text = "Vehicle Successfully Added";
                
            }
            catch(Exception ex)
            {
                lblsuccess.Text = "Vehicle Successfully Added";
            }
        }
    }
}