﻿using PayAndParkDAL.WCFServices;
using PayAndParkEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayAndParkDAL
{
    public class VehicleDAL
    {
        
        public void Add(Vehicle vehicle)
        {
            try
            {
                VehicleServiceClient proxy = new VehicleServiceClient();
                proxy.AddVehicle(vehicle);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    
    }
}
