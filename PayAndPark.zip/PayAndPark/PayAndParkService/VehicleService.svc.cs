﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using PayAndParkEntity;

namespace PayAndParkService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "VehicleService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select VehicleService.svc or VehicleService.svc.cs at the Solution Explorer and start debugging.
    [ServiceBehavior]
    public class VehicleService : IVehicleService
    {
        [OperationBehavior]
        public Vehicle AddVehicle(Vehicle vehicle)
        {
            try
            {


                using (SqlConnection connection = new SqlConnection())
                {
                    connection.ConnectionString = ConfigurationManager.ConnectionStrings["VehicleConnection"].ConnectionString;
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "prc_AddVehicle";
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@OwnerName", vehicle.OwnerName);
                        cmd.Parameters.AddWithValue("@ContactNo", vehicle.ContactNo);
                        cmd.Parameters.AddWithValue("@Date", vehicle.Date);
                        cmd.Parameters.AddWithValue("@RegistrationNo", vehicle.RegistrationNo);
                        cmd.Parameters.AddWithValue("@Amount", vehicle.Amount);
                        cmd.Parameters.AddWithValue("@TypeofVehicle", vehicle.TypeofVehicle);
                        cmd.ExecuteNonQuery();
                        connection.Close();
                        return vehicle;
                    }
                }
            }catch(Exception ex)
            {
                throw new FaultException(ex.Message);
            }
        }

       
    }
}
