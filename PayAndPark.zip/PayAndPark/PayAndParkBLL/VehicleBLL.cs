﻿using PayAndParkDAL;
using PayAndParkEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayAndParkBLL
{
    public class VehicleBLL
    {
        public void Add(Vehicle vehicle)
        {
            try
            {
                VehicleDAL dal = new VehicleDAL();
                dal.Add(vehicle);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
